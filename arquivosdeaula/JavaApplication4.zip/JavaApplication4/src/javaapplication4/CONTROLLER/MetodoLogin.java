/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication4.CONTROLLER;

/**
 *
 * @author 055911
 */
public class MetodoLogin {
    
    private String username = "rodrigo";
    
    private String senha = "123";
    
    public boolean autentica(String username, String senha){
    
        if(username.equals(this.username) && senha.equals(this.senha)){
            return true;
        }else{
             return false;
        }
    }
    
}
