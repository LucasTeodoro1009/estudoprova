/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication4.MODEL;

/**
 *
 * @author 055911
 */
public class BD {
    
    /*
       Métodos para trabalhar com o 
       Banco de dados.
    */
    
}
