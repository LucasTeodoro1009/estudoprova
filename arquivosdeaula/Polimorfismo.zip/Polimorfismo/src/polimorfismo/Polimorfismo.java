/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package polimorfismo;

import java.util.Scanner;

/**
 *
 * @author 055911
 */
public class Polimorfismo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         
        Animal a;
        double peso;
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Digite o peso do peixe:");
        peso = sc.nextDouble();
        
        a = new Peixe(peso);
        System.out.println("Peso inicial: "
                + a.getPeso());
        // alterar o peso
        a.setPeso(30.0);
        System.out.println("Novo Peso: "+a.getPeso()); // exibir o novo peso
        a.mover();
       /* 
        a = new Sapo();
        a.mover();
        
        a = new Passaro();
        a.mover();
        */
        
        
        

    }
    
}
