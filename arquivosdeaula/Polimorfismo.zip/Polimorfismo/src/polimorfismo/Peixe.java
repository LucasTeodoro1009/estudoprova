/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package polimorfismo;

/**
 *
 * @author 055911
 */
public class Peixe extends Animal{

    @Override
    public void mover() {
        System.out.println("O peixe nada!");  
    }
    
    // Construtor
    public Peixe(double peso){
      super(peso);
    }
    
    @Override
    public void setPeso(double peso){
       super.setPeso(peso);
    }
    
    @Override
    public double getPeso(){
      return super.getPeso();
    }
}
