/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication1;

/**
 *
 * @author 055911
 */
public class MinhaClasse {
    
    // atributos
    
    private int x;
    
    private double d;
    
    private String s;
    
    public void metodo1(){
        System.out.println("Metodo 1");
    }
    
    public int metodo2(int a, int b){
       return (a+b);
    }
    
    public static void imprimir(){
        System.out.println("teste");
    }
    
    public MinhaClasse(int x, double d, String s){
       this.x = x;
       this.d = d;
       this.s = s;
    }
    
    
    
    
    
}
