/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication1;

/**
 *
 * @author 055911
 */
public class JavaApplication1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        MinhaClasse.imprimir();
        
        
        MinhaClasse mc = new MinhaClasse(1, 2.0, "oi");
        
        mc.metodo1();
        
        System.out.println(">>>: " + mc.metodo2(2, 2));
        
        
        
        
    }
    
}
