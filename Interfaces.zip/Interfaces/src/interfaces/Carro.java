/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interfaces;

/**
 *
 * @author 055911
 */
public class Carro extends Veiculo{

    public Carro(int rodas) {
        super(rodas);
    }

    @Override
    public void abastecer() {
        System.out.println("Veiculo abastece!");
    }
    
    public void imprimirNavegacao(){
       super.navegar();
    }

    @Override
    public void ligar() {
        System.out.println("O carro liga");   
    }

  
    
}
