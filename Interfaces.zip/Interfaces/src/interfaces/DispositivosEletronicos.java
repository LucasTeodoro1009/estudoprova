/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interfaces;

/**
 *
 * @author 055911
 */
public abstract class DispositivosEletronicos
        implements GPS, Ligacao {
    
    private String modeloTela;
    
    public abstract void carregar();

    public DispositivosEletronicos(String modeloTela) {
        this.modeloTela = modeloTela;
    }

    public String getModeloTela() {
        return modeloTela;
    }

    public void setModeloTela(String modeloTela) {
        this.modeloTela = modeloTela;
    }
    
    public void Ligar(){
        System.out.println("Os dispositivos ligam");
    }
    
    
}


