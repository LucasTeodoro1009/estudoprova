/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interfaces;

/**
 *
 * @author 055911
 */
public class Celular extends DispositivosEletronicos{
    
    public Celular(String modeloTela) {
        super(modeloTela);
    }

    @Override
    public void carregar() {
        System.out.println("Dispositivo carregando!");
    }

    @Override
    public void navegar() {
        System.out.println("O celular Navega");
    }
    
}
