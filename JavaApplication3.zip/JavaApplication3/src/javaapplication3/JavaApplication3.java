/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication3;

/**
 *
 * @author 055911
 */
public class JavaApplication3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

           //Veiculo v = new Veiculo();
          /* 
           Carro c = new Carro();
           c.imprimir();
           System.out.println("Qdte: "+c.quantidade(10));

           Moto m =new Moto();
           System.out.println("=================");
           m.imprimir();
           System.out.println("Qtde: "+m.quantidade(2));
           */
           
           
           
    }
    
}
