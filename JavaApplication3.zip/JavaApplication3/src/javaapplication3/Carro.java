/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication3;

/**
 *
 * @author 055911
 */
public class Carro extends Terrestres{

    @Override
    public void mover() {
        System.out.println("Andar");
    }

    @Override
    public void abastecer() {
        System.out.println("Gasolina/Alcool");  
    }

    @Override
    public void imprimir() {
        System.out.println("Carro"); 
    }

    @Override
    public int quantidade(int qtde) {
        System.out.println("Qtde Rodas: "+qtde);
        return qtde;
    }

}
